package com.utn.practico1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Practico1Application {

	public static void main(String[] args) {
		SpringApplication.run(Practico1Application.class, args);
	}

}
